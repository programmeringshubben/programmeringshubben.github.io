﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DemoProjekt
{
    class Program
    {
        static void Main(string[] args)
        {
            // This is a call for the method (metodanrop) GreetUser. We use this to tell the computer to run our the method.
            // Note that GreetUser does not require parameters whereas AddNumbers does.
            GreetUser();

            AskUserAge();

            // Console.ReadLine() waits for user input. It is commonly utilized to allow for readability. Ie., giving us the ability to "pause" in intervals.
            Console.ReadLine();
        }

        /// <summary>
        /// The method prints "Hello!" to the console-window.
        /// </summary>
        private static void GreetUser()
        {
            Console.WriteLine("Hello!");
        }

        /// <summary>
        /// The method asks for user input concerning the user's year of birth as a numerical value, e.g., "1993". It then calculcates and prints the user's age.
        /// </summary>
        private static void AskUserAge()
        {
            // Console.WriteLine() the string within the parameters. In this case "What year were you born?".
            Console.WriteLine("What year were you born?");
            // Here we declare a variable of type string, which is a datatype that stores text, yearAsText. We then set it's value to whatever the user inputs by using Console.ReadLine().
            string yearAsText = Console.ReadLine();
            // Since we're asking the user to input a numerical value, the year they were born, we have to convert the string (yearAsText) to a variable of type integer (yearAsNumber).
            int yearAsNumber = Convert.ToInt32(yearAsText);
            // Here we utilize "DateTime.Now.Year" in order to auto-generate the current year and subtract the user's year of birth. I.e., something along the lines of 2018-1993. We then print this value along with some text.
            // Note that '+' is used to concatenate (sammanfoga) two strings. 
            Console.WriteLine("Wow, so that makes you " + (DateTime.Now.Year - yearAsNumber) + "!");
        }

        /// <summary>
        /// The method takes two integers as it's parameters, adds one parameter to the other and returns the sum total.
        /// I.e., given the parameters 3 and 5, the method will return 8.
        /// </summary>
        /// <param name="x">Represents the first parameter. E.g., if you write 3 in it's place when calling the method, x will represent a 3.</param>
        /// <param name="y">Represents the first parameter. E.g., if you write 5 in it's place when calling the method, y will represent a 5.</param>
        /// <returns>The sum of the addition between x and y.</returns>
        private static int AddNumbers(int x, int y)
        {
            // Write your implementation below. Remove the line "throw new NotImplementedException();" when you're done. Google/or otherwise lookup the keyword "return". Utilize this keyword to return the sum of your addition.
            // "throw new NotImplementedException();" is used as a temporary placeholder until we have implemented our method.
            throw new NotImplementedException();
        }
    }
}
